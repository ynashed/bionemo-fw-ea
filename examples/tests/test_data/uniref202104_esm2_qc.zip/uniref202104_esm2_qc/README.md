The data in this folder is a subset of the UniRef50 and UniRef90 datasets from UniProt 202104 release. The data has been processed following ESM-2 paper guidelines, and a subset of data with 5000 random UniRef50 train sequences and corresponding UniRef90 cluster members for sampling are contained here. For more information on how the data is prepared, please refer to BioNeMo Documentation on UniProt and ESM2 dataset.   

Please update relevant fiels in base_config.yaml, or use the appropriate mappings (indicated in bracket) for command line arguments.   
This assumes you are mounting the contents of this folder to /data/uniref202104_esm2/ in your container.  

## Pretraining dataset example (ESM-2nv)  
uf50_datapath (model.data.uf50_datapath): '/data/uniref202104_esm2/ur50_train_filt.fasta'  
ur90_datapath (model.data.uf90_datapath): '/data/uniref202104_esm2/uf90_ur50_sampler.fasta'
cluster_mapping_tsv (model.data.cluster_mapping_tsv): '/data/uniref202104_esm2/mapping.tsv'  

## Inference data example (ESM-2nv)  
uniref50_inference_example.csv  
